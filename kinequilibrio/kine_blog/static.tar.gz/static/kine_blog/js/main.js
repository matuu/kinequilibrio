$(document).ready(function(){
    /* Initialise bxSlider */
    $('.bxslider').bxSlider({
        captions: true
    });

    //Apply img-thumbnail class to body-content images
    $('.body-content img').addClass("img-thumbnail");
});